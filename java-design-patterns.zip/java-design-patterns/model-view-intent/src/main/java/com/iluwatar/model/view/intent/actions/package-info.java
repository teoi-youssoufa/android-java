/**
 * Handle actions for {@link com.iluwatar.model.view.intent.CalculatorModel}
 * defined by {@link com.iluwatar.model.view.intent.actions.CalculatorAction}.
 */

package com.iluwatar.model.view.intent.actions;
