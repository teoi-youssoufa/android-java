/**
 * Define Model, View and ViewModel.
 * Use them in {@link com.iluwatar.model.view.intent.App}
 */

package com.iluwatar.model.view.intent;
